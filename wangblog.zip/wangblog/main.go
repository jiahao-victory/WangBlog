package main

import (
	"wangblog/model"
	"wangblog/routes"
)

func main() {
	model.InitDb()
	routes.InitRouter()
}