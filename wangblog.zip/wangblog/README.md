# wangblog



#### 使用说明

1.	项目结构：
      Api/v1：这里主要作为对外接口的函数，在第二层
      Config：配置文件信息，里面存取server信息，database数据库信息，qiniu远程资源等信息
      Log：存放自定义日志信息和功能
      Middleware：中间件，主要有cors跨域请求，jwt认证，logger日志输出
      Model：各个模型的定义和对应方法
      Routes：路由信息和各个中间件的注册
      Utils：存放各个模块通用的数据，比如错误码等，还有数据格式认证等相关数据，数据库及配置文件加载等数据
      Web：存放前端界面
      Main：存放相关数据
2.	Api/v1相关路由接口
      	Article.go文件用来记录文章操作的路由接口
1.	AddArticle方法实现文章的添加，这里主要是将前端页面post过来的文章进行与models中的article进行绑定，绑定到model结构体中，利用了ShouldBindJson（&data）。
      然后将该data，用文章传递模型的方法进行添加，然后获取到状态码，进行返回等一系列数据。
2.	GetCateArt查询分类下地所有文章，首先获取到分类列表中地ID，然后获取到多少页，每页多少个数据项。然后传入分类ID，页码PagSize，每页多少个数据项PageNum，获取当前页的数据data，code状态码，total总量，然后返回。
3.	GetArtInfo查询单个文章信息，首先获取到当前文章的id，然后传入当前文章的id，获取到对应的文章1信息，然后返回。
4.	GetArt查询文章列表，这里主要就是获取所有的文章列表，这个就是对全部总类进行请求。首先获取到pageSize，和pageNum，页号和一页多少个。然后传入，获取到对应的数据，传出即可
5.	EditArt编辑文章，这里的主要作用就是，前端传递过来一个文章的结构体即model，然后获取到你要编辑的文章的id，c.Param(“id”)，然后将前端传递过来的数据绑定到你的结构体上面。然后传入当前结构体，和当前文章的id，然后编辑。返回获取的状态码和数据。
6.	DeleteArt删除文章，获取你要删除文章的id，然后删除，返回状态码，状态信息。
      	Category.go文件用来记录关于文件分类相关路由
1.	AddCategory，添加文件分类，将前端传递过来的数据绑定你定义的model上面，然后判断一下当前的分类是否存在，如果存在的化，那么就返回相关错误码及错误信息，不存在的化，将你绑定后的model传递进去进行创建。
2.	GetCate查询分类列表，查看一下你有多少个分类，这里主要是先获取到页码，和一页的大小，然后传递进去获取到对应的分类。返回相关数据。
3.	EditCate，编辑分类名，将前端要编辑的数据传递过来，绑定到相关model上，然后检查你要改的这个模型在系统里是否存在，如果存在的化，编辑失败，返回。可以更改的化，那么就进行编辑，返回对应的数据。
4.	DeleteCate，删除文章分类
      	Login.go主要实现关于登录相关路由，
1.	Login，先将你传递进来的用户及数据进行绑定，然后验证账号和密码是否相同，然后相同的化进行设置token进行返回。
      	Upload.go
1.	实现上传文件相关功能，先获取文件，然后将文件传入，进行上传。
      	User.go实现关于用户的相关操作
1.	AddUser，添加用户，先将前端传递过来的用户进行绑定和数据认证，查看一下是否有效，如果无效的化进行返回。同时判断一下当前用户在数据库中是否存在，如果不存在的化传递你从前端绑定的数据进行新建用户。然后返回相关结果。
2.	GetUsers查询用户列表，根据前端传递过来的页码和页号进性绑定，同时将绑定后的数据进行传递。
3.	EditUser，编辑用户，先获取你要编辑的用户id，然后将你从前端绑定的用户进行验证，判断下当前用户是否在数据库里，没有的化传递进去进行编辑。
4.	DeleteUser，删除用户，将你要删除的用户ID进行获取，然后进行删除。
3. config配置
   	Config.ini相关的配置
1.	Server下：
      AppMode：当前生产模式
      HttpPort：3000 对外暴露的端口
      JwtKey：进行jwt认证时的key
2.	Database：数据库相关配置
      Db：数据库类型比如Mysql
      DbHost：服务的主机地址
      DbPort：mysql的端口号
      DbUser：数据库用户
      DbPassWord：数据库密码
      DbName：数据库名称
3.	qiniu：七牛云相关配置，这里主要作用是存储图片
      AccessKey：AccessKey
      SecretKey：秘密key
      Bucket：管理空间
      QiniuServer：七牛云的服务地址
4. log日志
   	log.log：存放相关操作日志文件
5. middleware中间件
   	cors.go:主要处理跨域相关问题
1.	Cors：返回一个gin.HandlerFunc，新建一个配置信息，AllowOrigins：[]string{“*”}允许所有的域的请求AllowMethods：[]string{“*”}允许所有的请求方法ExposeHeaders：[]string{“contentLength”,”Authorization”}允许暴露的头部
      AllowHeaders:[]string{“origin”}允许的请求头
      MaxAge：准备响应前缓存持续的最大时间
      	Jwt.go:主要处理jwt认证相关信息
1.	JwtKey：用来进行签名的字符串
2.	MyClaims：自定义声明类型，jwt包自带的只包含了官方字段，如果我们需要额外记录一个username字段那么我们就需要自定义一个结构体进行签名和认证。
3.	SetToken，生成token，首先expireTime，设置过期时间10个小时，然后将该过期时间和你要添加的username一起添加到你的Claims里面；
      然后使用指定的签名方法将你创建的claim进行创建token；
      然后将你的宣称对象用你的jwtkey进行签名，返回你创建后的token。
4.	CheckToken验证token，如果是自定义的claim，需要使用ParseWithClaims方法，将你传递过来的字符串进行解析，解析成jwt包中的token，然后对token对象中的Claim进行断言，获取到claims和校验token是否有效，有效的化将其返回，返回了你自定义的claims了。
5.	JwtToken：中间件，进行验证用的，这个中间件的作用是，每次请求这次路由的时候都会调用一下这个函数。首先获取请求投中Authorization字段，客户端携带token有三种方式，1，放在请求头，2，放在请求体，3，放在uri中这里假设把Token放到authorization中。然后判断当前是否有token，没有的化进行返回。有的话将其分成俩个部分，首先判断首部是否以Bearer开头，如果不是的化返回错误验证失败。然后验证后面的Token，如果验证错误，不存在那么返回。如果到了过期时间，也进行返回。都通过的化，将请求头中的“username”字段设置成验证通过后的username。
      	Logger.go处理日志相关信息，将gin框架的日志重定向到文件里
1.	Logger函数：返回一个gin.HandlerFunc；首先，先赋值给文件路径，然后打开文件；生成一个日志文件工具，logger：=logrus.New()，将输出重定向到你打开的文件里。然后获取当前时间；c.Next()执行下面的中间件；获取当前停止时间；获取所花费的时间；获取主机名；获取状态码；获取客户端IP地址；获取数据大小；获取请求方法；获取请求的资源路径。然后将这些所有的东西写入到logger日志里面，即logger.WithFields(logrus.Fields(“字段“：”字段值“，…)，然后判断是否有错误；判断状态码；然后写入日志
6. model数据模型
   	 Article.go这里主要记录关于文章的增删改查相关模型
1.	Article Struct：该结构体主要用来记录文章相关模型比如Title，Cid，Desc等相关字段
2.	CreateArt：创建文章，根据前端传递过来的数据在上一层路由绑定好后的数据传递过来，然后db.Create(&data)用utils下的db工具进行写入数据库，即db.Create(&data).Error写入。
3.	GetCateArt：根据分类id，页码，页号获取分类列表下的所有文章。首先声明一个文章列表，和一个文章总数。然后db.Preload(“Category”).Limit(pageSize).Offset((pageNum-1)*pageSize).Where(“cid=?”,id).Find(&cateArtList).Count(&total).Error,这条语句对应的sql语句为：select count（1）from article where cid =id limit pageSize offset （pageNum-1）*pageSize，然后返回
4.	GetArtInfo：查询单个文章，根据传递过来的文章id进行查询，查询函数为db.Preload(“Category“).Where(“id=?”,id).First(&art)对应的Sql语句为select * from article where id=id；然后返回对应的结构体，前端进行展示。
5.	GetArt：查询所有文章，和之前一样，只不过没有对应的分类Id了。
6.	EditArt：编辑文章分类信息，将前端传递过来的数据绑定后传递过来；生成一个Map，用map记录各个字段更新各个字段，然后使用db.Model(&art).Where(“id=?”,id).Update(maps).Error,即对应的SQL语句为：update art set id=“对应字段”……;然后返回对应的状态码。
      	Category.go记录对应的目录信息
1.	Category struct：记录目录相关信息。
2.	ChechCategory：查询分类是否存在，db.Select(“id”).Where(“name=？“，name).First（&cate）对应的SQL语句为：select id from Category where name=”name”
3.	CreateCate:新增分类，db.Create(&data).error;对应的SQL语句为inser into category values（“value”…）
4.	GetCate：查询分类列表，db.Limit(pageSize).Offset((pageNum-1)*pageSize).Find(&cate)对应的SQL语句为：select * from category limit pageSize offset (PageNum-1)*PageSize);
5.	EditCate:编辑分类信息，将传递过来的数据进行更新，db.Model(&cate).Where(“id=?”,id).Update(maps).Error对应的sql语句为update category set name=“name” where id =”id”;
6.	DeleteCate:删除对应的分类，db.Where(“id=?”,id).Delete(&category{})对应的Sql语句为delete from Category where id =“id”；
      	Db.go这个文件主要用来初始化数据库的，应该放在Setting里面这里为了方便将它放到了model里面。
1.	Var db *gorm.DB初始化引擎，var err error创建error
2.	InitDb：初始化数据库，gorm.Open(utils.Db,fmt.Sprintf(……………………)；打开对应的数据库类型，然后db.SingularTable(true)设置为禁用默认表名的复数形式，db.AutoMigrate(&User{},&Article{},&Category{})将对应的模型迁移成对应的表。Db.DB().SetMaxIdleConns(10)设置连接池中空闲连接的最大数量。Db.DB().SetMaxOpenConns(100)设置打开数据库连接的最大数量。Db.DB().SetConnMaxLifetime(10*time.Second)设置了连接可复用的最大时间。
      	UpLoadFile.go将文件上传,因为这里要将文件上传到七牛云上面所以配置了AccessKey等配置信息
1.	var AccessKey=utils.AccessKey
      var SecretKey=utils.SecretKey
      var Bucket=utils.Bucket
      var ImgUrl=utils.QiniuServer
      这里就看一下官方文档吧，在七牛云上面命名空间管理上。
      	User.go这个文件主要处理了关于User模型的相关信息
1.	UserStruct：存储User数据类型的数据结构
2.	CheckUser：查询用户是否存在，db.Select(“id“).Where(“username=?”,name).First(&users)对应的sql语句为select id from users where username=”name”
3.	CreateUser：新增用户，将从前端绑定后的数据进行添加，db.Create(&data)对应的Sql语句即为Sql语句，然后将其返回状态码。
4.	GetUsers：查询用户列表，db.Limit(pageSize).Offset((pageNum-1)*pageSize).Find(&usrs).Count(&total)对应的Sql语句为select * from users limit pagesize offset (pagenum-1)*pageSize)
5.	EditUser:编辑用户信息，将从前端传递过来的序号和对应的数据进行插入即可，db.Model(&user).Where(“id=?”,id).Update(maps)对应的Sql语句为update users set 字段=字段值 where id =id;
6.	DeleteUser:删除用户，db.Where(“id=?”,id).Delete(&User{})对应的Sql语句为delete from users where id=1;
7.	ScryptPw:对应的密码加密这里调用了Scrypt包直接调用这个方法，scrypt.Key([]byte(password),salt,16384,6,1,keylen)就可以对你的密码进行加密了，然后将你得到的密码是一个byte，将其进行base64编码返回即可。
8.	CheckLogin：登录验证，将床底过来的用户名进行数据库查找，找到后将前端传递过来的密码进行加密和数据库后加密的数据进行验证，如果通过则返回，不行的化则退出。
